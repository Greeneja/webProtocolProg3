﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace prog1.Prog3.App_Code
{
    public class SQLDataClass
    {
        public static DataTable table;
        //public static string addProduct(string ID, string Name, double Price, string Description)
        //{
        //    try
        //    {
        //        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UWPCS3870ConnectionString"].ConnectionString);
        //        conn.Open();
        //        string checkProd = "Select count(*) From Product where ProductID = '" + ID + "' and Name = '" + Name + "'";
        //        SqlCommand com1 = new SqlCommand(checkProd, conn);
        //        int temp = Convert.ToInt32(com1.ExecuteScalar().ToString());
        //        if (temp == 1)
        //        {
        //            conn.Close();
        //            return "Product already exists";
        //        }
        //        else
        //        {
        //            //SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UWPCS3870ConnectionString"].ConnectionString);
        //            //conn.Open();
        //            string insertQuery = "insert into Product(ProductID, ProductName, UnitPrice, Description)" +
        //                " values (@pID, @pName, @pPrice, @pDesc)";
        //            SqlCommand com2 = new SqlCommand(insertQuery, conn);
        //            com2.Parameters.AddWithValue("@pID", ID);
        //            com2.Parameters.AddWithValue("@pName", Name);
        //            com2.Parameters.AddWithValue("@pPrice", Price);
        //            com2.Parameters.AddWithValue("@pDesc", Description);
        //            com2.ExecuteNonQuery();
        //            conn.Close();
        //            return "Submitted Successfully";
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        return ("Error: " + ex.Message);
        //    }
        //}

        ////public List<string> getProduct(string ID, string Name)
        ////{
        ////    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["AccountingConnectionString"].ConnectionString);
        ////    conn.Open();
        ////    string checkProd = "Select count(*) From Product where ProductID = '" + ID + "' and Name = '" + Name + "'";
        ////    SqlCommand com = new SqlCommand(checkProd, conn);
        ////    int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
        ////    if (temp == 1)
        ////    {
        ////        SqlDataAdapter dataAdapter = new SqlDataAdapter(com);
        ////        DataSet dataSet = new DataSet();
        ////        dataAdapter.Fill(dataSet);
        ////        table = dataSet.Tables[0];
        ////        return table
        ////    }
        ////    conn.Close();
        ////}

        //public static DataTable GetTable()
        //{
        //    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UWPCS3870ConnectionString"].ConnectionString);
        //    conn.Open();
        //    string checkProd = "Select * From Product";
        //    SqlCommand com = new SqlCommand(checkProd, conn);
        //    SqlDataAdapter dataAdapter = new SqlDataAdapter(com);
        //    DataSet dataSet = new DataSet();
        //    dataAdapter.Fill(dataSet);
        //    table = dataSet.Tables[0];
        //    return table;
        //}

        //private const string ConStr = "Data Source=Alpha;" +
        //    "Initial Catalog = UWPCS3870; Persist Security Info=True;" +
        //    "User ID = MSCS; Password = MasterInCS";
        private static System.Data.SqlClient.SqlDataAdapter prodAdapter;
        private static SqlCommand prodCmd = new SqlCommand();
        private static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["UWPCS3870ConnectionString"].ConnectionString);
        public static DataTable tblProduct = new DataTable("Product");

        public static void setupProdAdapter
()
        {
            //con.ConnectionString = ConStr;
            prodCmd.Connection = con;
            prodCmd.CommandType = CommandType.Text;
            prodCmd.CommandText = "Select * from Product order by ProductID";
            prodAdapter = new SqlDataAdapter(prodCmd);
            prodAdapter.FillSchema(tblProduct, SchemaType.Source);
        }

        public static void getAllProducts()
        {
            if (prodAdapter == null)
            {
                setupProdAdapter();
            }
            prodCmd.CommandText = "Select * from Product order by ProductID";
            try
            {
                if (!(tblProduct == null))
                {
                    tblProduct.Clear();
                }
                prodAdapter.Fill(tblProduct);
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                con.Close();
            }
        }

        public static void UpdateProduct(string theID, string newName, double newPrice, string newDesc)
        {
            prodCmd.CommandText = "Update Product " +
            "Set ProductName = '" + newName + "', " +
            "UnitPrice = " + newPrice + ", " +
            "Description = '" + newDesc + "' " +
            "Where ProductID = '" + theID + "'";
            try
            {
                con.Open();
                prodCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public static void DeleteProduct(string theID)
        {
            prodCmd.CommandText = "Delete From Product " +
                "Where ProductID ='" + theID + "'";
            try
            {
                con.Open();
                prodCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public static void AddProduct(string theID, string Name, double Price, string Desc)
        {
            //prodCmd.CommandText = "Insert Into Product(ProductID, ProductName, UnitPrice, Description) " +
            //    "Values(‘" + theID + "’, ‘" + Name + "’, " + Price + ", ‘" + Desc + "’)";
            prodCmd.CommandText = "insert into Product(ProductID, ProductName, UnitPrice, Description)" +
                    " values (@pID, @pName, @pPrice, @pDesc)";
            prodCmd.Parameters.AddWithValue("@pID", theID);
            prodCmd.Parameters.AddWithValue("@pName", Name);
            prodCmd.Parameters.AddWithValue("@pPrice", Price);
            prodCmd.Parameters.AddWithValue("@pDesc", Desc);
            try
            {
                con.Open();
                prodCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}