﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace prog1.Prog3.App_Code
{
    public class SQLDataClass
    {
        public static DataTable table;
        public static string addProduct(string ID, string Name, double Price, string Description)
        {
            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UWPCS3870ConnectionString"].ConnectionString);
                conn.Open();
                string checkProd = "Select count(*) From Product where ProductID = '" + ID + "' and Name = '" + Name + "'";
                SqlCommand com1 = new SqlCommand(checkProd, conn);
                int temp = Convert.ToInt32(com1.ExecuteScalar().ToString());
                if (temp == 1)
                {
                    conn.Close();
                    return "Product already exists";
                }
                else
                {
                    //SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UWPCS3870ConnectionString"].ConnectionString);
                    //conn.Open();
                    string insertQuery = "insert into Product(ProductID, ProductName, UnitPrice, Description)" +
                        " values (@pID, @pName, @pPrice, @pDesc)";
                    SqlCommand com2 = new SqlCommand(insertQuery, conn);
                    com2.Parameters.AddWithValue("@pID", ID);
                    com2.Parameters.AddWithValue("@pName", Name);
                    com2.Parameters.AddWithValue("@pPrice", Price);
                    com2.Parameters.AddWithValue("@pDesc", Description);
                    com2.ExecuteNonQuery();
                    conn.Close();
                    return "Submitted Successfully";
                }

            }
            catch (Exception ex)
            {
                return ("Error: " + ex.Message);
            }
        }

        //public List<string> getProduct(string ID, string Name)
        //{
        //    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["AccountingConnectionString"].ConnectionString);
        //    conn.Open();
        //    string checkProd = "Select count(*) From Product where ProductID = '" + ID + "' and Name = '" + Name + "'";
        //    SqlCommand com = new SqlCommand(checkProd, conn);
        //    int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
        //    if (temp == 1)
        //    {
        //        SqlDataAdapter dataAdapter = new SqlDataAdapter(com);
        //        DataSet dataSet = new DataSet();
        //        dataAdapter.Fill(dataSet);
        //        table = dataSet.Tables[0];
        //        return table
        //    }
        //    conn.Close();
        //}

        public static DataTable GetTable()
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UWPCS3870ConnectionString"].ConnectionString);
            conn.Open();
            string checkProd = "Select * From Product";
            SqlCommand com = new SqlCommand(checkProd, conn);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(com);
            DataSet dataSet = new DataSet();
            dataAdapter.Fill(dataSet);
            table = dataSet.Tables[0];
            return table;
        }
    }
}