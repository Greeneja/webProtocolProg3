﻿using prog1.Prog3.App_Code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prog1.Prog3
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        private DataTable prodTable
        {
            get
            {
                if (Session["prodTable"] == null)
                {
                    Session["prodTable"] = null;
                }
                return (DataTable)Session["prodTable"];
            }
            set { Session["prodTable"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (!IsPostBack)
            {
                prodTable = SQLDataClass.GetTable();
            }
        }

        protected void btnFirst_Click(object sender, EventArgs e)
        {

        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {

        }

        protected void btnNext_Click(object sender, EventArgs e)
        {

        }

        protected void btnLast_Click(object sender, EventArgs e)
        {

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //SQLDataClass.
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {

        }

        protected void btnNew_Click(object sender, EventArgs e)
        {

        }
    }
}