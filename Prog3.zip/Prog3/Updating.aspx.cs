﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prog1.Prog3
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        //private DataTable prodTable
        //{
        //    get
        //    {
        //        if (Session["prodTable"] == null)
        //        {
        //            Session["prodTable"] = null;
        //        }
        //        return (DataTable)Session["prodTable"];
        //    }
        //    set { Session["prodTable"] = value; }
        //}
        private string[] keepIDs = new string[5] {"p101", "p103", "p107", "p109", "p201"};
        
        private int Prog3_Index
        {
            get
            {
                if (Session["Prog3_Index"] != null)
                {
                    return (int)Session["Prog3_Index"];
                }
                else
                {
                    return 0;
                }
            }
            set { Session["Prog3_Index"] = value; }
        }

        private int past_Index
        {
            get
            {
                if (Session["past_Index"] != null)
                {
                    return (int)Session["past_Index"];
                }
                else
                {
                    return 0;
                }
            }
            set { Session["past_Index"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            //if (!IsPostBack)
            //{
            //    prodTable = SQLDataClass.GetTable();
            //}
            txtMessage.Text = "";
            if (!IsPostBack)
            {
                DisplayRow(Prog3_Index);
            }
            if (Prog3_Index == 0)
            {
                btnFirst.Enabled = false;
                btnPrevious.Enabled = false;
            }
            else if (Prog3_Index == App_Code.SQLDataClass.tblProduct.Rows.Count - 1)
            {
                btnLast.Enabled = false;
                btnNext.Enabled = false;
            }
        }

        protected void btnFirst_Click(object sender, EventArgs e)
        {
            Prog3_Index = 0;
            DisplayRow(Prog3_Index);
            btnFirst.Enabled = false;
            btnPrevious.Enabled = false;
            btnLast.Enabled = true;
            btnNext.Enabled = true;
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            int index = Prog3_Index - 1;
            if (index < 0)
            {
                index = 0;
            }
            Prog3_Index = index;
            DisplayRow(index);
            btnLast.Enabled = true;
            btnNext.Enabled = true;
            if (Prog3_Index == 0)
            {
                btnFirst.Enabled = false;
                btnPrevious.Enabled = false;
            }
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            int index = Prog3_Index + 1;
            if (index > App_Code.SQLDataClass.tblProduct.Rows.Count - 1)
            {
                index = App_Code.SQLDataClass.tblProduct.Rows.Count - 1;
            }
            Prog3_Index = index;
            DisplayRow(index);
            btnFirst.Enabled = true;
            btnPrevious.Enabled = true;
            if (Prog3_Index == App_Code.SQLDataClass.tblProduct.Rows.Count - 1)
            {
                btnLast.Enabled = false;
                btnNext.Enabled = false;
            }
        }

        protected void btnLast_Click(object sender, EventArgs e)
        {
            Prog3_Index = App_Code.SQLDataClass.tblProduct.Rows.Count - 1;
            DisplayRow(Prog3_Index);
            btnLast.Enabled = false;
            btnNext.Enabled = false;
            btnFirst.Enabled = true;
            btnPrevious.Enabled = true;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string theID = txtID.Text;
                string newName = txtName.Text;
                double newPrice = double.Parse(txtPrice.Text.Replace("$", ""));
                string newDesc = txtDescription.Text;
                App_Code.SQLDataClass.UpdateProduct(theID, newName, newPrice, newDesc);
                txtMessage.Text = "Record updated.";
                App_Code.SQLDataClass.getAllProducts();
            }
            catch (Exception ex)
            {
                txtMessage.Text = "Product Not Updated: " + ex.Message;
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            bool deletable = true;
            if (btnDelete.Text == "Delete")
            {
                try
                {
                    string theID = txtID.Text;
                    for (int i = 0; i < keepIDs.Count(); i++)
                    {
                        if (theID == keepIDs[i])
                        {
                            deletable = false;
                        }
                    }
                    if (deletable)
                    {
                        App_Code.SQLDataClass.DeleteProduct(theID);
                        txtMessage.Text = "Record Deleted.";
                        Prog3_Index = Prog3_Index - 1;
                        App_Code.SQLDataClass.getAllProducts();
                        DisplayRow(Prog3_Index);
                    }
                    else
                    {
                        txtMessage.Text = "Record cannot be Deleted.";
                    }
                }
                catch (Exception ex)
                {
                    txtMessage.Text = "Product Not Deleted: " + ex.Message;
                }
            }
            else
            {
                Prog3_Index = Prog3_Index - 1;
                App_Code.SQLDataClass.getAllProducts();
                DisplayRow(Prog3_Index);
                btnNew.Text = "New";
                btnDelete.Text = "Delete";
                btnUpdate.Enabled = true;
                btnFirst.Enabled = true;
                btnPrevious.Enabled = true;
            }
            
        }

        protected void btnNew_Click(object sender, EventArgs e)
        {
            if (btnNew.Text == "New")
            {
                past_Index = Prog3_Index;
                Prog3_Index = App_Code.SQLDataClass.tblProduct.Rows.Count;
                txtID.Text = "";
                txtName.Text = "";
                txtPrice.Text = "";
                txtDescription.Text = "";
                txtMessage.Text = "";
                btnFirst.Enabled = false;
                btnPrevious.Enabled = false;
                btnNext.Enabled = false;
                btnLast.Enabled = false;
                btnUpdate.Enabled = false;
                btnNew.Text = "Save New";
                btnDelete.Text = "Cancel";
            }
            else
            {
                try
                {
                    for (int i = 0; i < App_Code.SQLDataClass.tblProduct.Rows.Count; i++)
                    {
                        TableRow row = new TableRow();
                        TableCell cell = new TableCell();
                        if (App_Code.SQLDataClass.tblProduct.Rows[i][0].ToString() == txtID.Text)
                        {
                            txtMessage.Text = "ID already exists.";
                        }
                        //cell.Text = prodTable.Rows[i][j].ToString();
                        //row.Cells.Add(cell);
                    }
                    if (txtMessage.Text != "ID already exists.")
                    {
                        btnNew.Text = "New";
                        btnDelete.Text = "Delete";
                        string theID = txtID.Text;
                        string Name = txtName.Text;
                        double Price = double.Parse(txtPrice.Text.Replace("$", ""));
                        string Desc = txtDescription.Text;
                        App_Code.SQLDataClass.AddProduct(theID, Name, Price, Desc);
                        btnFirst.Enabled = true;
                        btnPrevious.Enabled = true;
                        btnUpdate.Enabled = true;
                        txtMessage.Text = "Record Added.";
                        App_Code.SQLDataClass.getAllProducts();
                    }
                }
                catch (Exception ex)
                {
                    txtMessage.Text = "Product Not Added: " + ex.Message;
                }
            }
        }

        private void DisplayRow(int index)
        {
            DataRow row = App_Code.SQLDataClass.tblProduct.Rows[index];
            txtID.Text = row[0].ToString();
            txtName.Text = row[1].ToString();
            txtPrice.Text = string.Format("{0:C}", row[2]);
            txtDescription.Text = row[3].ToString();
        }
    }
}