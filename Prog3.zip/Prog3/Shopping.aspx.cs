﻿using prog1.Prog3.App_Code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prog1.Prog3
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        private const double tax = 0.055;
        private const int COL_1 = 0;
        private const int COL_2 = 1;
        private const int COL_3 = 2;
        private const int COL_4 = 3;

        private double subtotal
        {
            get
            {
                if (Session["subtotal"] == null)
                {
                    Session["subtotal"] = 0;
                }
                return (double)Session["subtotal"];
            }
            set { Session["subtotal"] = value; }
        }

        private double grandTotal
        {
            get
            {
                if (Session["grandTotal"] != null)
                {
                    return (double)Session["grandTotal"];
                }
                else
                {
                    return 0;
                }
            }
            set { Session["grandTotal"] = value; }
        }

        private double taxTotal
        {
            get
            {
                if (Session["taxTotal"] != null)
                {
                    return (double)Session["taxTotal"];
                }
                else
                {
                    return 0;
                }
            }
            set { Session["taxTotal"] = value; }
        }

        private DataTable prodTable
        {
            get
            {
                if (Session["prodTable"] == null)
                {
                    Session["prodTable"] = null;
                }
                return (DataTable)Session["prodTable"];
            }
            set { Session["prodTable"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if(!IsPostBack)
            {
                prodTable = SQLDataClass.GetTable();
            }
        }

        protected void btnCompute_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < prodTable.Rows.Count; i++)
                {
                    TableRow row = new TableRow();
                    TableCell cell = new TableCell();
                    if (prodTable.Rows[i][COL_1].ToString() == txtID.Text && prodTable.Rows[i][COL_2].ToString() == txtName.Text)
                    {
                        txtPrice.Text = prodTable.Rows[i][COL_3].ToString();
                    }
                    //cell.Text = prodTable.Rows[i][j].ToString();
                    //row.Cells.Add(cell);
                }
                txtID.ReadOnly = true;
                txtName.ReadOnly = true;
                txtQuantity.ReadOnly = true;
                subtotal = double.Parse(txtPrice.Text) * double.Parse(txtQuantity.Text);
                txtSubTotal.Text = subtotal.ToString();
                taxTotal = subtotal * tax;
                txtTax.Text = taxTotal.ToString();
                grandTotal = subtotal + taxTotal;
                txtGrandTotal.Text = grandTotal.ToString();
                txtPrice.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtSubTotal.Text));
                txtSubTotal.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtSubTotal.Text));
                txtTax.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtTax.Text));
                txtGrandTotal.Text = string.Format("$ {0:#,##0.00}", double.Parse(txtGrandTotal.Text));
                btnReset.Focus();

            }
            catch(Exception ex)
            {
                Response.Write("Error: " + ex.Message);
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtID.ReadOnly = false;
            txtName.ReadOnly = false;
            txtQuantity.ReadOnly = false;
            txtID.Text = "";
            txtName.Text = "";
            txtPrice.Text = "";
            txtQuantity.Text = "";
            txtSubTotal.Text = "";
            txtTax.Text = "";
            txtGrandTotal.Text = "";
            txtID.Focus();
        }
    }
}